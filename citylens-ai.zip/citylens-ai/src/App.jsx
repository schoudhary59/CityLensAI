import { useState, useEffect } from 'react'
import InputPage from './pages/InputPage.jsx'
import ResultsPage from './pages/ResultsPage.jsx'

export default function App() {
  const [results, setResults] = useState(null)
  const [demoMode, setDemoMode] = useState(false)

  // Demo mode: Ctrl+Shift+D
  useEffect(() => {
    const handler = (e) => {
      if (e.ctrlKey && e.shiftKey && e.key === 'D') {
        setDemoMode(prev => {
          const next = !prev
          console.log(`%cCityLens Demo Mode: ${next ? '✅ ON' : '❌ OFF'}`,
            `color:${next ? '#22c55e' : '#ef4444'};font-weight:bold;font-size:14px;`)
          return next
        })
      }
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [])

  const handleResult = (data) => {
    setResults(data)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const handleReset = () => {
    setResults(null)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <div style={{ fontFamily: 'var(--font-body)', minHeight: '100vh', background: 'var(--color-bg)' }}>
      {/* Demo mode badge */}
      {demoMode && (
        <div style={{
          position: 'fixed', top: 8, right: 8, zIndex: 9999,
          background: '#16A34A', color: 'white',
          padding: '4px 12px', borderRadius: 20,
          fontSize: 11, fontFamily: 'var(--font-mono)',
          pointerEvents: 'none', userSelect: 'none'
        }}>
          🎬 DEMO MODE
        </div>
      )}

      {/* Header */}
      <header style={{
        position: 'sticky', top: 0, zIndex: 40,
        background: 'rgba(248,250,252,0.95)',
        backdropFilter: 'blur(12px)',
        borderBottom: '1px solid var(--color-border)',
        boxShadow: '0 1px 3px rgba(0,0,0,0.06)'
      }}>
        <div style={{ maxWidth: 680, margin: '0 auto', padding: '12px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <button
            onClick={handleReset}
            style={{ display: 'flex', alignItems: 'center', gap: 10, background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}
          >
            <div style={{
              width: 34, height: 34, borderRadius: 10,
              background: 'linear-gradient(135deg, #2563EB, #1B3A5C)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: '0 2px 8px rgba(37,99,235,0.3)'
            }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                <circle cx="12" cy="12" r="3" fill="white"/>
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z" fill="white" opacity="0.6"/>
                <path d="M12 6.5L8.5 10H11v8h2v-8h2.5L12 6.5z" fill="white"/>
              </svg>
            </div>
            <div style={{ textAlign: 'left' }}>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16, color: 'var(--color-navy)', lineHeight: 1 }}>
                CityLens AI
              </div>
              <div style={{ fontSize: 10, color: 'var(--color-text-secondary)', fontFamily: 'var(--font-mono)', marginTop: 2 }}>
                Montgomery Permit Guide
              </div>
            </div>
          </button>

          {results && (
            <button
              onClick={handleReset}
              style={{
                fontSize: 13, color: 'var(--color-text-secondary)',
                background: 'none', border: '1px solid var(--color-border)',
                borderRadius: 8, padding: '6px 14px', cursor: 'pointer',
                fontFamily: 'var(--font-body)'
              }}
            >
              ← New Search
            </button>
          )}
        </div>
      </header>

      {/* Main content */}
      <main>
        {results ? (
          <ResultsPage data={results} onReset={handleReset} />
        ) : (
          <InputPage onResult={handleResult} demoMode={demoMode} />
        )}
      </main>

      {/* Footer */}
      <footer style={{
        borderTop: '1px solid var(--color-border)',
        background: 'white',
        marginTop: 60,
        padding: '28px 20px'
      }}>
        <div style={{ maxWidth: 680, margin: '0 auto', textAlign: 'center' }}>
          <p style={{ fontSize: 12, color: 'var(--color-text-secondary)', marginBottom: 6, fontFamily: 'var(--font-mono)' }}>
            CityLens AI · Montgomery, Alabama's civic permit navigator
          </p>
          <p style={{ fontSize: 11, color: '#94A3B8', marginBottom: 6 }}>
            Data sourced from official City of Montgomery and Alabama state records · Knowledge base verified March 2026
          </p>
          <p style={{ fontSize: 11, color: '#94A3B8' }}>
            This tool provides guidance only — not legal advice. Always confirm requirements with the relevant government office before filing.
          </p>
        </div>
      </footer>
    </div>
  )
}
