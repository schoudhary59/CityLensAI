import { useState } from 'react'
import PermitCard from '../components/PermitCard.jsx'

export default function ResultsPage({ data, onReset }) {
  const [spanish, setSpanish] = useState(false)
  const [spanishData, setSpanishData] = useState(null)
  const [translating, setTranslating] = useState(false)
  const [translateError, setTranslateError] = useState(null)
  const [pdfLoading, setPdfLoading] = useState(false)

  const displayData = spanish && spanishData ? spanishData : data

  const handleSpanishToggle = async () => {
    if (spanish) { setSpanish(false); return }
    if (spanishData) { setSpanish(true); return }

    setTranslating(true)
    setTranslateError(null)
    try {
      const res = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ roadmap: data }),
      })
      if (!res.ok) throw new Error('Translation failed')
      const translated = await res.json()
      setSpanishData(translated)
      setSpanish(true)
    } catch {
      setTranslateError('Translation unavailable. Please try again.')
    } finally {
      setTranslating(false)
    }
  }

  const handlePDF = async () => {
    setPdfLoading(true)
    try {
      // Dynamic import jsPDF
      const { jsPDF } = await import('jspdf')
      const doc = new jsPDF({ format: 'letter', unit: 'mm', orientation: 'portrait' })
      const margin = 20
      const contentWidth = 170
      let y = margin

      const addText = (str, size = 10, style = 'normal', color = [30, 41, 59]) => {
        if (!str) return
        doc.setFontSize(size)
        doc.setFont('helvetica', style)
        doc.setTextColor(...color)
        const lines = doc.splitTextToSize(String(str), contentWidth)
        if (y + lines.length * (size * 0.38) > 270) { doc.addPage(); y = margin }
        doc.text(lines, margin, y)
        y += lines.length * (size * 0.38) + 2
      }

      const gap = (n = 4) => { y += n }
      const hr = (c = [220,220,220]) => { doc.setDrawColor(...c); doc.line(margin, y, 210-margin, y); y += 5 }

      // Header
      doc.setFillColor(27, 58, 92)
      doc.roundedRect(margin, y-2, contentWidth, 20, 3, 3, 'F')
      doc.setFontSize(16); doc.setFont('helvetica','bold'); doc.setTextColor(255,255,255)
      doc.text('CityLens AI — Permit Roadmap', margin+4, y+11); y += 24

      addText(`Business Type: ${displayData.business_type}`, 12, 'bold', [27,58,92])
      addText(`Estimated Total: ${data.total_cost_range}   ·   Timeline: ${data.timeline_weeks} weeks   ·   ${data.permits.length} Permits`, 10, 'normal', [37,99,235])
      addText(`Generated: ${new Date().toLocaleDateString()} · Knowledge base verified: March 2026`, 9, 'normal', [148,163,184])
      gap(); hr()

      // First Action
      doc.setFillColor(220,252,231); doc.roundedRect(margin, y, contentWidth, 24, 2, 2, 'F')
      doc.setTextColor(22,101,52); doc.setFont('helvetica','bold'); doc.setFontSize(10)
      doc.text('✅ FIRST ACTION TODAY', margin+3, y+8)
      doc.setFont('helvetica','normal'); doc.setFontSize(9); doc.setTextColor(20,83,45)
      const actionLines = doc.splitTextToSize(displayData.first_action, contentWidth-6)
      doc.text(actionLines, margin+3, y+14); y += actionLines.length*3.5+18

      // Permits
      addText('PERMIT CHECKLIST', 12, 'bold', [27,58,92]); hr([200,200,220])
      displayData.permits.forEach(p => {
        if (y > 250) { doc.addPage(); y = margin }
        addText(`Step ${p.step}: ${p.name}`, 11, 'bold', [30,30,30])
        addText(`Why: ${p.why}`, 9, 'normal', [71,85,105])
        addText(`Fee: ${p.fee_range} — ${p.fee_note}`, 9, 'normal', [71,85,105])
        addText(`${p.department}`, 9, 'bold', [37,99,235])
        addText(`${p.address} · ${p.phone} · ${p.hours}`, 9, 'normal', [100,116,139])
        addText(`Source: ${p.source}`, 8, 'normal', [148,163,184])
        gap(3)
      })

      // Risks
      if (y > 250) { doc.addPage(); y = margin }
      gap(4); addText('⚠️ REJECTION RISK WARNINGS', 11, 'bold', [180,100,0]); hr([220,160,100])
      displayData.rejection_risks.forEach(r => {
        if (y > 250) { doc.addPage(); y = margin }
        addText(`⚠ ${r.warning}`, 10, 'bold', [146,64,14])
        addText(r.detail, 9, 'normal', [120,53,15]); gap(2)
      })

      // Disclaimer
      gap(6); hr(); addText('LEGAL NOTICE', 9, 'bold', [148,163,184])
      addText(displayData.disclaimer, 8, 'normal', [148,163,184])

      // Footer
      const pageCount = doc.internal.getNumberOfPages()
      for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i); doc.setFontSize(8); doc.setTextColor(200,200,200)
        doc.text('CityLens AI — citylensai.com', margin, 285)
        doc.text(`Page ${i} of ${pageCount}`, 210-margin-15, 285)
      }

      doc.save(`CityLens-${data.business_type_id}-roadmap.pdf`)
    } catch (err) {
      console.error('PDF error:', err)
      alert('PDF generation failed. Please try again.')
    } finally {
      setPdfLoading(false)
    }
  }

  const confidenceBadge = {
    high: { label: 'High Confidence', bg: '#DCFCE7', color: '#166534', border: '#BBF7D0' },
    medium: { label: 'Medium Confidence — Verify at office', bg: '#FEF3C7', color: '#92400E', border: '#FDE68A' },
    low: { label: 'Low Confidence — Call to confirm', bg: '#FEE2E2', color: '#991B1B', border: '#FECACA' },
  }[data.classification_confidence] || { label: 'Verified', bg: '#DCFCE7', color: '#166534', border: '#BBF7D0' }

  return (
    <div style={{ maxWidth: 680, margin: '0 auto', padding: '32px 20px 80px' }}>

      {/* Classification Banner */}
      <div className="animate-fade-in" style={{
        background: 'var(--color-navy)',
        borderRadius: 16, padding: '18px 22px',
        marginBottom: 12,
        boxShadow: '0 4px 20px rgba(27,58,92,0.25)'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8 }}>
          <div>
            <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.6)', fontFamily: 'var(--font-mono)', marginBottom: 4, textTransform: 'uppercase', letterSpacing: '0.08em' }}>
              Business Type Identified
            </div>
            <div style={{ fontSize: 20, fontFamily: 'var(--font-display)', fontWeight: 700, color: 'white' }}>
              📋 {displayData.business_type}
            </div>
          </div>
          <div style={{
            background: confidenceBadge.bg,
            color: confidenceBadge.color,
            border: `1px solid ${confidenceBadge.border}`,
            borderRadius: 20, padding: '5px 12px', fontSize: 12,
            fontFamily: 'var(--font-mono)', whiteSpace: 'nowrap'
          }}>
            {confidenceBadge.label}
          </div>
        </div>
      </div>

      {/* Summary Strip */}
      <div className="animate-fade-in-delay-1" style={{
        display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10,
        marginBottom: 16
      }}>
        {[
          { label: 'Estimated Total', value: data.total_cost_range, icon: '💰' },
          { label: 'Timeline', value: `${data.timeline_weeks} weeks`, icon: '📅' },
          { label: 'Permits Required', value: `${data.permits.length} steps`, icon: '📋' },
        ].map((stat, i) => (
          <div key={i} style={{
            background: 'white',
            borderRadius: 12, border: '1px solid var(--color-border)',
            padding: '12px 14px', textAlign: 'center'
          }}>
            <div style={{ fontSize: 18 }}>{stat.icon}</div>
            <div style={{ fontSize: 15, fontWeight: 700, color: '#2563EB', margin: '4px 0 2px', fontFamily: 'var(--font-mono)' }}>
              {stat.value}
            </div>
            <div style={{ fontSize: 11, color: 'var(--color-text-secondary)' }}>{stat.label}</div>
          </div>
        ))}
      </div>

      {/* First Action Box */}
      <div className="animate-fade-in-delay-2" style={{
        background: 'var(--color-green)',
        borderRadius: 16, padding: '18px 20px',
        marginBottom: 20,
        boxShadow: '0 4px 16px rgba(22,163,74,0.25)'
      }}>
        <div style={{ display: 'flex', gap: 12 }}>
          <span style={{ fontSize: 24, flexShrink: 0 }}>✅</span>
          <div>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16, color: 'white', marginBottom: 6 }}>
              First Action Today
            </div>
            <p style={{ fontSize: 14, color: 'rgba(255,255,255,0.95)', lineHeight: 1.6, margin: 0 }}>
              {displayData.first_action.replace(/(\d{3}-\d{3}-\d{4})/g, (phone) => phone)}
            </p>
          </div>
        </div>
      </div>

      {/* Permit Checklist */}
      <div className="animate-fade-in-delay-3">
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 18, color: 'var(--color-navy)', marginBottom: 12 }}>
          Your Permit Checklist
        </h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 24 }}>
          {displayData.permits.map((permit, i) => (
            <PermitCard key={permit.step} permit={permit} index={i} />
          ))}
        </div>
      </div>

      {/* Risk Warnings */}
      <div className="animate-fade-in-delay-4">
        <div style={{
          background: '#FFFBEB',
          border: '1px solid #FDE68A',
          borderRadius: 16, overflow: 'hidden', marginBottom: 24
        }}>
          <div style={{
            background: '#D97706', padding: '12px 18px',
            display: 'flex', alignItems: 'center', gap: 8
          }}>
            <span style={{ fontSize: 16 }}>⚠️</span>
            <span style={{ fontWeight: 700, fontSize: 14, color: 'white', fontFamily: 'var(--font-display)' }}>
              Common Mistakes That Delay {displayData.business_type} Applications
            </span>
          </div>
          <div style={{ padding: '16px 18px', display: 'flex', flexDirection: 'column', gap: 14 }}>
            {displayData.rejection_risks.map((risk, i) => (
              <div key={i} style={{ paddingBottom: i < displayData.rejection_risks.length - 1 ? 14 : 0, borderBottom: i < displayData.rejection_risks.length - 1 ? '1px solid #FDE68A' : 'none' }}>
                <div style={{ fontWeight: 700, fontSize: 13, color: '#92400E', marginBottom: 4 }}>
                  ⚠ {risk.warning}
                </div>
                <div style={{ fontSize: 13, color: '#78350F', lineHeight: 1.6 }}>
                  {risk.detail}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="animate-fade-in-delay-5" style={{ display: 'flex', gap: 10, marginBottom: 20, flexWrap: 'wrap' }}>
        <button
          onClick={handlePDF}
          disabled={pdfLoading}
          style={{
            flex: 1, minWidth: 160, height: 46,
            borderRadius: 12, border: '1.5px solid #2563EB',
            background: 'white', color: '#2563EB',
            fontSize: 14, fontWeight: 600,
            fontFamily: 'var(--font-body)', cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
            transition: 'all 0.15s'
          }}
          onMouseEnter={e => { e.currentTarget.style.background = '#EFF6FF' }}
          onMouseLeave={e => { e.currentTarget.style.background = 'white' }}
        >
          {pdfLoading ? 'Generating...' : '⬇️ Download PDF'}
        </button>

        <button
          onClick={handleSpanishToggle}
          disabled={translating}
          style={{
            flex: 1, minWidth: 160, height: 46,
            borderRadius: 12, border: '1.5px solid var(--color-border)',
            background: 'white', color: 'var(--color-text-secondary)',
            fontSize: 14, fontWeight: 600,
            fontFamily: 'var(--font-body)', cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
            transition: 'all 0.15s'
          }}
          onMouseEnter={e => { e.currentTarget.style.borderColor = '#64748B' }}
          onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--color-border)' }}
        >
          {translating ? 'Translating...' : spanish ? '🇺🇸 View in English' : '🌎 Ver en Español'}
        </button>
      </div>

      {translateError && (
        <div style={{ fontSize: 12, color: '#92400E', background: '#FFFBEB', border: '1px solid #FDE68A', borderRadius: 8, padding: '8px 12px', marginBottom: 16 }}>
          {translateError}
        </div>
      )}

      {/* Legal Disclaimer */}
      <div style={{
        background: '#F8FAFC', border: '1px solid var(--color-border)',
        borderRadius: 12, padding: '14px 16px', marginBottom: 20
      }}>
        <p style={{ fontSize: 12, color: '#94A3B8', lineHeight: 1.7, margin: 0 }}>
          <strong style={{ color: '#64748B' }}>⚠️ Important notice:</strong> {displayData.disclaimer}
        </p>
      </div>

      {/* Footer actions */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 10 }}>
        <button
          onClick={onReset}
          style={{
            fontSize: 13, color: 'var(--color-text-secondary)',
            background: 'none', border: 'none', cursor: 'pointer',
            fontFamily: 'var(--font-body)', padding: 0
          }}
        >
          ← Search a different business
        </button>
        <a
          href={`mailto:feedback@citylensai.com?subject=CityLens Feedback&body=Business type: ${data.business_type_id}%0A%0A`}
          style={{ fontSize: 13, color: '#94A3B8', textDecoration: 'none' }}
        >
          Was this helpful? Flag an error ↗
        </a>
      </div>
    </div>
  )
}
