import { useState, useRef, useEffect } from 'react'

const DEMO_RESPONSES = {
  hair_braiding: {
    business_type: "Hair Braiding Salon",
    business_type_id: "hair_braiding",
    classification_confidence: "high",
    total_cost_range: "$285-$410",
    timeline_weeks: "3-4",
    permits: [
      { step: 1, name: "Zoning Verification", why: "Your chosen location must be zoned for personal service establishments before you sign any lease or begin renovations.", fee_range: "$0", fee_note: "Zoning verification is free — but skipping it can cost you thousands in a lost deposit.", department: "City of Montgomery Land Use Division", address: "City Hall, 103 N Perry St, Montgomery, AL 36104", phone: "334-625-2722", hours: "Mon–Fri, 8:00 AM–5:00 PM", source: "City of Montgomery Zoning Ordinance, Chapter 7", source_url: "" },
      { step: 2, name: "City of Montgomery Business License", why: "Required for any business operating within Montgomery city limits.", fee_range: "$100-$200", fee_note: "Varies by gross revenue bracket. Confirm exact amount at office.", department: "City of Montgomery License & Revenue Division", address: "25 Washington Ave, 3rd Floor, Montgomery, AL 36104", phone: "334-625-2036", hours: "Mon–Fri, 7:30 AM–4:30 PM", source: "City of Montgomery Code of Ordinances, Chapter 5", source_url: "https://www.montgomeryal.gov/work/business-resources/license-and-revenue" },
      { step: 3, name: "Certificate of Occupancy", why: "No commercial building may be legally occupied for business without a Certificate of Occupancy. Required before opening to clients.", fee_range: "$75-$150", fee_note: "Fee depends on square footage and inspection scope. Confirm at office.", department: "City of Montgomery Building Inspection Department", address: "25 Washington Ave, Montgomery, AL 36104", phone: "334-625-2073", hours: "Mon–Fri, 8:00 AM–4:30 PM", source: "City of Montgomery Building Code; Code of Alabama §11-43-130", source_url: "" },
      { step: 4, name: "Alabama Natural Hair Stylist License (Personal)", why: "Alabama requires a separate Natural Hair Stylist license for braiding, locking, and twisting without chemicals. A cosmetology license does NOT cover this.", fee_range: "$50-$100", fee_note: "License fee set by ABOC. Requires completing approved training hours.", department: "Alabama Board of Cosmetology and Barbering (ABOC)", address: "P.O. Box 301750, Montgomery, AL 36130", phone: "334-242-1918", hours: "Mon–Fri, 8:30 AM–4:30 PM", source: "Alabama Code §34-7B; ABOC Natural Hair Care Regulations", source_url: "https://aboc.alabama.gov/licensing/" },
      { step: 5, name: "ABOC Shop License", why: "In addition to your personal Natural Hair Stylist license, the salon location itself requires a separate shop license from ABOC.", fee_range: "$60-$120", fee_note: "Shop license is per location and expires September 30th in odd-numbered years. Must renew by October 31st.", department: "Alabama Board of Cosmetology and Barbering (ABOC)", address: "P.O. Box 301750, Montgomery, AL 36130", phone: "334-242-1918", hours: "Mon–Fri, 8:30 AM–4:30 PM", source: "Alabama Code §34-7B; ABOC Shop License Requirements", source_url: "https://aboc.alabama.gov/licensing/" }
    ],
    first_action: "Call the City of Montgomery Land Use Division at 334-625-2722 to verify your chosen location is zoned for personal service establishments before signing any lease. This is the most common delay for hair braiding salon applications.",
    rejection_risks: [
      { warning: "Zoning not verified before lease signing", detail: "Not all C-1 commercial zones permit personal service establishments. Contact the Land Use Division (334-625-2722) before committing to any location — losing a deposit is the most common costly mistake." },
      { warning: "Assuming cosmetology license covers braiding", detail: "Alabama requires a separate Natural Hair Stylist license for braiding, locking, and twisting without chemicals. Your cosmetology license alone is not sufficient." },
      { warning: "Personal license does not cover the shop", detail: "Your individual Natural Hair Stylist license does not authorize the salon location itself to operate. A separate ABOC shop license is required per location." }
    ],
    disclaimer: "This is guidance based on publicly available Montgomery and Alabama state information, not legal advice. Always confirm requirements with the relevant office before filing."
  },
  food_truck: {
    business_type: "Food Truck / Mobile Vendor",
    business_type_id: "food_truck",
    classification_confidence: "high",
    total_cost_range: "$340-$520",
    timeline_weeks: "4-6",
    permits: [
      { step: 1, name: "City of Montgomery Business License", why: "Required for any business operating within Montgomery city limits.", fee_range: "$100-$200", fee_note: "Varies by gross revenue bracket. Confirm exact amount at office.", department: "City of Montgomery License & Revenue Division", address: "25 Washington Ave, 3rd Floor, Montgomery, AL 36104", phone: "334-625-2036", hours: "Mon–Fri, 7:30 AM–4:30 PM", source: "City of Montgomery Code of Ordinances, Chapter 5", source_url: "https://www.montgomeryal.gov/work/business-resources/license-and-revenue" },
      { step: 2, name: "Alabama Secretary of State — Business Entity Registration", why: "Register your business entity (LLC or sole proprietorship) before operating.", fee_range: "$28-$200", fee_note: "Sole proprietorship DBA is lowest cost. LLC formation is $200.", department: "Alabama Secretary of State, Business Services Division", address: "Online at sos.alabama.gov — or P.O. Box 5616, Montgomery AL 36103", phone: "334-242-5324", hours: "Mon–Fri, 8:00 AM–5:00 PM", source: "Code of Alabama, Title 10A", source_url: "https://www.sos.alabama.gov/government-records/business-entity-records" },
      { step: 3, name: "ADPH Mobile Food Unit Plan Review & Permit", why: "Alabama state law requires all mobile food units to submit a plan of operations and pass inspection before serving the public.", fee_range: "$100-$300", fee_note: "Fee varies by menu risk category (Cat. 1–4). BBQ cooking = Category 3.", department: "Montgomery County Environmental Health (ADPH)", address: "3060 Mobile Hwy, Montgomery, AL 36108", phone: "334-293-6400", hours: "Mon–Fri, 8:00 AM–5:00 PM", source: "ADPH Food Sanitation Rules 420-3-22-.09", source_url: "https://www.alabamapublichealth.gov/foodsafety/assets/mobilefoodrequirements.pdf" },
      { step: 4, name: "Commissary Agreement", why: "Alabama law requires food trucks to operate from an approved commissary kitchen for food storage, water filling, and waste disposal.", fee_range: "$0-$150/month", fee_note: "Cost depends on commissary rental agreement. Must be in place before health inspection.", department: "Montgomery County Environmental Health (ADPH)", address: "3060 Mobile Hwy, Montgomery, AL 36108", phone: "334-293-6400", hours: "Mon–Fri, 8:00 AM–5:00 PM", source: "ADPH Mobile Food Requirements, Commissary Standards Rule 420-3-22-.09", source_url: "https://www.alabamapublichealth.gov/foodsafety/assets/mobilefoodrequirements.pdf" },
      { step: 5, name: "Food Handler Certification (per employee)", why: "Every employee who prepares or serves food in Alabama must obtain a Food Handler Card within 30 days of hire.", fee_range: "$15 per person", fee_note: "Alabama state law caps this fee at $15.", department: "ADPH-approved testing providers (ServSafe or equivalent)", address: "Multiple locations — see alabamapublichealth.gov", phone: "334-206-5373", hours: "Varies by testing site", source: "Alabama Code §22-20A", source_url: "https://www.alabamapublichealth.gov/foodsafety/" },
      { step: 6, name: "City Food Truck List Registration", why: "To operate at city-hosted events and festivals, food trucks must be registered with the Special Events Director.", fee_range: "$0", fee_note: "Registration is free. Direct contact required.", department: "City of Montgomery Special Events Office", address: "City Hall, 103 N Perry St, Montgomery, AL 36104", phone: "334-625-2114", hours: "Mon–Fri, 8:00 AM–5:00 PM", source: "City of Montgomery Food Truck Ordinance (2015)", source_url: "https://www.montgomeryal.gov" }
    ],
    first_action: "Call the Montgomery County Environmental Health office at 334-293-6400 to schedule your mobile food unit plan review. This step has the longest lead time and must be completed before your truck can operate. Have your proposed menu and commissary information ready.",
    rejection_risks: [
      { warning: "No commissary agreement before health inspection", detail: "Your health permit application will be denied if you cannot show a signed agreement with an ADPH-approved commissary kitchen. Secure this before scheduling any inspections." },
      { warning: "Parking within 300 feet of a brick-and-mortar restaurant", detail: "Montgomery's 2015 Food Truck Ordinance prohibits operating within 300 feet of a restaurant without permission. Scope all regular locations before launch." },
      { warning: "Not on the City Food Truck List", detail: "To participate in city-hosted events and festivals, you must contact the Special Events Director at 334-625-2114 in advance. This cannot be done the day of an event." }
    ],
    disclaimer: "This is guidance based on publicly available Montgomery and Alabama state information, not legal advice. Always confirm requirements with the relevant office before filing."
  }
}

const CHIPS = [
  { label: '🚚 Food Truck', value: 'I want to open a food truck selling BBQ near downtown Montgomery' },
  { label: '✂️ Hair Braiding', value: 'I want to open a hair braiding salon near Alabama State University in Montgomery' },
  { label: '🌿 Landscaping', value: 'I want to start a landscaping and lawn care business in Montgomery' },
]

export default function InputPage({ onResult, demoMode }) {
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [showModal, setShowModal] = useState(false)
  const textareaRef = useRef(null)

  useEffect(() => {
    const seen = localStorage.getItem('citylens_tutorial_seen')
    if (!seen) setShowModal(true)
  }, [])

  const handleSubmit = async () => {
    const trimmed = input.trim()
    if (trimmed.length < 10) {
      setError('Please describe your business in at least 10 characters.')
      return
    }
    setError(null)
    setLoading(true)

    // Demo mode shortcut
    if (demoMode) {
      const lower = trimmed.toLowerCase()
      let cached = null
      if (lower.includes('braid') || lower.includes('natural hair')) cached = DEMO_RESPONSES.hair_braiding
      else if (lower.includes('food truck') || lower.includes('bbq')) cached = DEMO_RESPONSES.food_truck
      if (cached) {
        setTimeout(() => { onResult(cached); setLoading(false) }, 600)
        return
      }
    }

    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userInput: trimmed }),
      })

      const data = await res.json()

      if (!res.ok || data.error) {
        setError(data.error || 'Unable to generate your roadmap. Please try again.')
        setLoading(false)
        return
      }

      if (data.clarifying_question) {
        setError(`❓ ${data.clarifying_question}`)
        setLoading(false)
        return
      }

      onResult(data)
    } catch (err) {
      setError('Network error — please check your connection and try again.')
    } finally {
      setLoading(false)
    }
  }

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) handleSubmit()
  }

  const canSubmit = input.trim().length >= 10 && !loading

  return (
    <>
      {/* Tutorial Modal */}
      {showModal && <TutorialModal onClose={() => {
        setShowModal(false)
        localStorage.setItem('citylens_tutorial_seen', '1')
        textareaRef.current?.focus()
      }} />}

      <div style={{ maxWidth: 600, margin: '0 auto', padding: '48px 20px 80px' }}>
        {/* Hero */}
        <div className="animate-fade-in" style={{ textAlign: 'center', marginBottom: 36 }}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 6,
            background: '#EFF6FF', border: '1px solid #BFDBFE',
            borderRadius: 20, padding: '6px 14px', marginBottom: 20
          }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#2563EB', display: 'inline-block' }} className="dot-pulse" />
            <span style={{ fontSize: 12, color: '#2563EB', fontFamily: 'var(--font-mono)' }}>
              Free · No account · Under 60 seconds
            </span>
          </div>

          <h1 style={{
            fontFamily: 'var(--font-display)',
            fontSize: 'clamp(26px, 5vw, 36px)',
            fontWeight: 800,
            lineHeight: 1.15,
            color: 'var(--color-navy)',
            margin: '0 0 14px',
          }}>
            What permits do you need to open your business in Montgomery?
          </h1>

          <p style={{ fontSize: 16, color: 'var(--color-text-secondary)', margin: 0, lineHeight: 1.5 }}>
            Describe your business below. We'll tell you exactly what to do — in the right order, with real fees and contacts.
          </p>
        </div>

        {/* Input card */}
        <div className="animate-fade-in-delay-1" style={{
          background: 'white',
          borderRadius: 20,
          border: '1px solid var(--color-border)',
          padding: 24,
          boxShadow: '0 4px 24px rgba(0,0,0,0.06)'
        }}>
          <textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => { setInput(e.target.value); setError(null) }}
            onKeyDown={handleKeyDown}
            placeholder="Example: I want to open a food truck selling BBQ near downtown Montgomery"
            style={{
              width: '100%',
              minHeight: 120,
              padding: '14px 16px',
              borderRadius: 12,
              border: '1.5px solid var(--color-border)',
              fontFamily: 'var(--font-body)',
              fontSize: 15,
              lineHeight: 1.6,
              color: 'var(--color-text)',
              resize: 'none',
              outline: 'none',
              transition: 'border-color 0.15s',
              background: '#FAFBFC'
            }}
            onFocus={(e) => e.target.style.borderColor = '#2563EB'}
            onBlur={(e) => e.target.style.borderColor = 'var(--color-border)'}
            aria-label="Describe your business"
          />

          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 6, marginBottom: 14 }}>
            <span style={{ fontSize: 12, color: input.trim().length >= 10 ? '#16A34A' : '#94A3B8', fontFamily: 'var(--font-mono)' }}>
              {input.trim().length >= 10 ? '✓ Ready to submit' : `${Math.max(0, 10 - input.trim().length)} more characters needed`}
            </span>
            <span style={{ fontSize: 11, color: '#CBD5E1', fontFamily: 'var(--font-mono)' }}>⌘+Enter to submit</span>
          </div>

          {/* Example chips */}
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 16 }}>
            {CHIPS.map(chip => (
              <button
                key={chip.label}
                onClick={() => { setInput(chip.value); setError(null); textareaRef.current?.focus() }}
                style={{
                  padding: '7px 14px',
                  borderRadius: 20,
                  border: '1px solid var(--color-border)',
                  background: 'white',
                  fontSize: 13,
                  color: 'var(--color-text-secondary)',
                  cursor: 'pointer',
                  fontFamily: 'var(--font-body)',
                  transition: 'all 0.15s'
                }}
                onMouseEnter={(e) => { e.target.style.borderColor = '#2563EB'; e.target.style.color = '#2563EB'; e.target.style.background = '#EFF6FF' }}
                onMouseLeave={(e) => { e.target.style.borderColor = 'var(--color-border)'; e.target.style.color = 'var(--color-text-secondary)'; e.target.style.background = 'white' }}
              >
                {chip.label}
              </button>
            ))}
          </div>

          {/* Error message */}
          {error && (
            <div style={{
              background: error.startsWith('❓') ? '#FFFBEB' : '#FEF2F2',
              border: `1px solid ${error.startsWith('❓') ? '#FCD34D' : '#FECACA'}`,
              borderRadius: 10, padding: '10px 14px',
              fontSize: 13, color: error.startsWith('❓') ? '#92400E' : '#991B1B',
              marginBottom: 14, lineHeight: 1.5
            }}>
              {error}
            </div>
          )}

          {/* Submit button */}
          <button
            onClick={handleSubmit}
            disabled={!canSubmit}
            style={{
              width: '100%',
              height: 50,
              borderRadius: 12,
              border: 'none',
              background: canSubmit ? 'linear-gradient(135deg, #2563EB, #1B3A5C)' : '#E2E8F0',
              color: canSubmit ? 'white' : '#94A3B8',
              fontSize: 15,
              fontWeight: 600,
              fontFamily: 'var(--font-body)',
              cursor: canSubmit ? 'pointer' : 'not-allowed',
              transition: 'all 0.15s',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              boxShadow: canSubmit ? '0 4px 14px rgba(37,99,235,0.35)' : 'none'
            }}
          >
            {loading ? (
              <>
                <div style={{ display: 'flex', gap: 4 }}>
                  {[0,1,2].map(i => (
                    <div key={i} className="load-dot" style={{ width: 6, height: 6, borderRadius: '50%', background: '#2563EB' }} />
                  ))}
                </div>
                <span style={{ color: 'var(--color-text-secondary)' }}>Analyzing your business...</span>
              </>
            ) : (
              <>Get My Permit Roadmap <span style={{ fontSize: 18 }}>→</span></>
            )}
          </button>
        </div>

        {/* Trust signals */}
        <div className="animate-fade-in-delay-2" style={{ textAlign: 'center', marginTop: 24 }}>
          <p style={{ fontSize: 12, color: '#94A3B8', marginBottom: 8, fontFamily: 'var(--font-mono)' }}>
            Data from official Montgomery City and Alabama State records
          </p>
          <div style={{ display: 'flex', justifyContent: 'center', gap: 16, flexWrap: 'wrap' }}>
            {['City of Montgomery', 'ADPH', 'Alabama SOS', 'ABOC'].map(org => (
              <span key={org} style={{ fontSize: 11, color: '#CBD5E1', fontFamily: 'var(--font-mono)' }}>{org}</span>
            ))}
          </div>
          <p style={{ fontSize: 11, color: '#CBD5E1', marginTop: 8, fontFamily: 'var(--font-mono)' }}>
            Knowledge base verified: March 2026
          </p>
        </div>

        {/* How it works */}
        <div className="animate-fade-in-delay-3" style={{ marginTop: 48 }}>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 20, color: 'var(--color-navy)', textAlign: 'center', marginBottom: 24 }}>
            How CityLens Works
          </h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
            {[
              { icon: '✍️', title: 'Describe your business', desc: 'In plain English — no forms, no dropdowns, no checkboxes' },
              { icon: '🤖', title: 'AI classifies your type', desc: 'We match you to the correct permit pathway from verified data' },
              { icon: '📋', title: 'Get your roadmap', desc: 'Ordered steps, real fees, direct phone numbers, first action today' },
            ].map((step, i) => (
              <div key={i} style={{ textAlign: 'center', padding: 16 }}>
                <div style={{ fontSize: 28, marginBottom: 10 }}>{step.icon}</div>
                <div style={{ fontWeight: 600, fontSize: 13, color: 'var(--color-navy)', marginBottom: 6 }}>{step.title}</div>
                <div style={{ fontSize: 12, color: 'var(--color-text-secondary)', lineHeight: 1.5 }}>{step.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  )
}

function TutorialModal({ onClose }) {
  const [openCard, setOpenCard] = useState(0)
  const [dontShow, setDontShow] = useState(false)

  const handleClose = () => {
    if (dontShow) localStorage.setItem('citylens_tutorial_seen', '1')
    onClose()
  }

  const cards = [
    { icon: '📋', title: 'Your Personalized Roadmap', brief: 'Describe your business, get your exact permit checklist.', detail: 'Every roadmap is ordered by legal sequence — not alphabetical, not generic. Each step shows the right department contact for Montgomery, with fees and timeline estimates so you can plan your launch.' },
    { icon: '💰', title: 'Real Fees & Contacts', brief: 'Official costs and department contacts — no guessing.', detail: 'Fees verified from official city and state schedules. Direct phone numbers for every office you need to call. Office hours included so you show up when they\'re open.' },
    { icon: '⚠️', title: 'Rejection Risk Warnings', brief: 'We flag the top mistakes that delay approvals.', detail: 'The most common sequence mistakes (like health inspection before CoO), location and zoning traps to verify before signing a lease, and missing credentials specific to your business type.' },
    { icon: '🌎', title: 'Available in Spanish', brief: 'Toggle to Spanish with one click — no account needed.', detail: 'One click translates your entire roadmap to Spanish. Department names and phone numbers stay in English as listed on official records. Switch back anytime.' },
  ]

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 100,
      background: 'rgba(15,23,42,0.7)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: 20, backdropFilter: 'blur(4px)'
    }} onClick={handleClose}>
      <div
        onClick={e => e.stopPropagation()}
        style={{
          background: 'white', borderRadius: 20,
          width: '100%', maxWidth: 480,
          maxHeight: '90vh', overflowY: 'auto',
          boxShadow: '0 20px 60px rgba(0,0,0,0.3)'
        }}
      >
        {/* Header */}
        <div style={{ padding: '24px 24px 0', textAlign: 'center' }}>
          <div style={{
            width: 52, height: 52, borderRadius: 14,
            background: 'linear-gradient(135deg, #2563EB, #1B3A5C)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            margin: '0 auto 14px', boxShadow: '0 4px 14px rgba(37,99,235,0.35)'
          }}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <circle cx="12" cy="12" r="3" fill="white"/>
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z" fill="white" opacity="0.6"/>
            </svg>
          </div>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 22, color: 'var(--color-navy)', margin: '0 0 6px' }}>
            Welcome to CityLens AI
          </h2>
          <p style={{ fontSize: 14, color: 'var(--color-text-secondary)', margin: 0 }}>
            Montgomery's free business permit navigator
          </p>
        </div>

        {/* Feature cards */}
        <div style={{ padding: '20px 20px 0' }}>
          {cards.map((card, i) => (
            <div key={i} style={{ marginBottom: 8 }}>
              <button
                onClick={() => setOpenCard(openCard === i ? -1 : i)}
                style={{
                  width: '100%', textAlign: 'left', padding: '14px 16px',
                  borderRadius: 12, border: '1.5px solid',
                  borderColor: openCard === i ? '#BFDBFE' : 'var(--color-border)',
                  background: openCard === i ? '#EFF6FF' : 'white',
                  cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 12,
                  transition: 'all 0.15s', fontFamily: 'var(--font-body)'
                }}
              >
                <span style={{ fontSize: 22, flexShrink: 0 }}>{card.icon}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: 13, color: 'var(--color-navy)' }}>{card.title}</div>
                  <div style={{ fontSize: 12, color: 'var(--color-text-secondary)', marginTop: 2 }}>{card.brief}</div>
                </div>
                <span style={{ color: '#94A3B8', fontSize: 12, flexShrink: 0 }}>{openCard === i ? '▲' : '▼'}</span>
              </button>
              {openCard === i && (
                <div style={{
                  padding: '12px 16px',
                  background: '#F8FAFC',
                  borderRadius: '0 0 12px 12px',
                  border: '1.5px solid #BFDBFE',
                  borderTop: 'none',
                  fontSize: 13,
                  color: 'var(--color-text-secondary)',
                  lineHeight: 1.6
                }}>
                  {card.detail}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Disclaimer */}
        <div style={{ margin: '16px 20px', padding: '10px 14px', background: '#F8FAFC', borderRadius: 10, fontSize: 11, color: '#94A3B8', lineHeight: 1.6 }}>
          CityLens AI gives guidance based on publicly available Montgomery and Alabama state data — not legal advice. Always confirm requirements with City Hall before filing.
        </div>

        {/* Footer */}
        <div style={{ padding: '0 20px 20px' }}>
          <button
            onClick={handleClose}
            style={{
              width: '100%', height: 46, borderRadius: 12,
              border: 'none', background: 'linear-gradient(135deg, #2563EB, #1B3A5C)',
              color: 'white', fontSize: 14, fontWeight: 600,
              fontFamily: 'var(--font-body)', cursor: 'pointer',
              boxShadow: '0 4px 14px rgba(37,99,235,0.35)',
              marginBottom: 10
            }}
          >
            Get Started →
          </button>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
            <input
              type="checkbox"
              id="dont-show"
              checked={dontShow}
              onChange={e => setDontShow(e.target.checked)}
              style={{ cursor: 'pointer' }}
            />
            <label htmlFor="dont-show" style={{ fontSize: 12, color: '#94A3B8', cursor: 'pointer' }}>
              Don't show this again
            </label>
          </div>
        </div>
      </div>
    </div>
  )
}
