import { useState } from 'react'

export default function PermitCard({ permit, index }) {
  const [expanded, setExpanded] = useState(false)

  const makePhoneClickable = (text) => {
    if (!text) return text
    const parts = text.split(/([\d]{3}-[\d]{3}-[\d]{4})/)
    return parts.map((part, i) =>
      /\d{3}-\d{3}-\d{4}/.test(part)
        ? <a key={i} href={`tel:${part.replace(/-/g,'')}`} style={{ color: '#2563EB', fontWeight: 600, textDecoration: 'none' }}>{part}</a>
        : part
    )
  }

  const delays = ['animate-fade-in-delay-1', 'animate-fade-in-delay-2', 'animate-fade-in-delay-3', 'animate-fade-in-delay-4', 'animate-fade-in-delay-5']
  const delayClass = delays[Math.min(index, 4)]

  return (
    <div
      className={delayClass}
      style={{
        background: 'white',
        borderRadius: 14,
        border: `1.5px solid ${expanded ? '#BFDBFE' : 'var(--color-border)'}`,
        overflow: 'hidden',
        transition: 'border-color 0.15s, box-shadow 0.15s',
        boxShadow: expanded ? '0 4px 16px rgba(37,99,235,0.08)' : '0 1px 3px rgba(0,0,0,0.04)'
      }}
    >
      {/* Collapsed row */}
      <button
        onClick={() => setExpanded(!expanded)}
        style={{
          width: '100%', padding: '14px 16px',
          display: 'flex', alignItems: 'center', gap: 12,
          background: 'none', border: 'none', cursor: 'pointer',
          textAlign: 'left', fontFamily: 'var(--font-body)'
        }}
      >
        {/* Step number */}
        <div style={{
          width: 34, height: 34, borderRadius: 10, flexShrink: 0,
          background: expanded ? '#2563EB' : '#EFF6FF',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontWeight: 800, fontSize: 14,
          color: expanded ? 'white' : '#2563EB',
          transition: 'all 0.15s', fontFamily: 'var(--font-mono)'
        }}>
          {permit.step}
        </div>

        {/* Name + fee */}
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontWeight: 600, fontSize: 14, color: 'var(--color-navy)', lineHeight: 1.3, marginBottom: 2 }}>
            {permit.name}
          </div>
          <div style={{ fontSize: 12, color: 'var(--color-text-secondary)', fontFamily: 'var(--font-mono)' }}>
            {permit.fee_range}
          </div>
        </div>

        {/* Dept + chevron */}
        <div style={{ flexShrink: 0, display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontSize: 11, color: '#94A3B8', display: 'none', maxWidth: 120 }} className="sm:block">
            {permit.department.split(' ').slice(0,3).join(' ')}...
          </span>
          <svg
            width="16" height="16" viewBox="0 0 24 24" fill="none"
            style={{ transform: expanded ? 'rotate(180deg)' : 'rotate(0)', transition: 'transform 0.2s', color: '#94A3B8', flexShrink: 0 }}
          >
            <path d="M6 9l6 6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
      </button>

      {/* Expanded detail */}
      {expanded && (
        <div className="animate-slide-down" style={{
          borderTop: '1px solid #EFF6FF',
          background: '#FAFCFF',
          padding: '16px 18px',
          display: 'flex', flexDirection: 'column', gap: 14
        }}>
          {/* Why */}
          <div>
            <div style={{ fontSize: 10, fontWeight: 700, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.1em', fontFamily: 'var(--font-mono)', marginBottom: 5 }}>
              Why You Need This
            </div>
            <p style={{ fontSize: 14, color: 'var(--color-text)', lineHeight: 1.6, margin: 0 }}>
              {permit.why}
            </p>
          </div>

          {/* Where to go */}
          <div>
            <div style={{ fontSize: 10, fontWeight: 700, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.1em', fontFamily: 'var(--font-mono)', marginBottom: 5 }}>
              Where to Go
            </div>
            <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--color-navy)', marginBottom: 3 }}>
              {permit.department}
            </div>
            <div style={{ fontSize: 13, color: 'var(--color-text-secondary)', marginBottom: 6 }}>
              📍 {permit.address}
            </div>
            <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
              <a
                href={`tel:${permit.phone.replace(/-/g,'')}`}
                style={{ fontSize: 13, color: '#2563EB', fontWeight: 600, textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 4 }}
              >
                📞 {permit.phone}
              </a>
              <span style={{ fontSize: 13, color: '#64748B', display: 'flex', alignItems: 'center', gap: 4 }}>
                🕐 {permit.hours}
              </span>
            </div>
          </div>

          {/* Fee */}
          <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.1em', fontFamily: 'var(--font-mono)', marginBottom: 5 }}>
                Fee
              </div>
              <div style={{ fontSize: 15, fontWeight: 700, color: '#2563EB', fontFamily: 'var(--font-mono)' }}>
                {permit.fee_range}
              </div>
              {permit.fee_note && (
                <div style={{ fontSize: 12, color: '#64748B', fontStyle: 'italic', marginTop: 3 }}>
                  {permit.fee_note}
                </div>
              )}
            </div>
          </div>

          {/* Source */}
          <div style={{
            paddingTop: 12, borderTop: '1px solid #E2E8F0',
            display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8, flexWrap: 'wrap'
          }}>
            <div style={{ fontSize: 11, color: '#94A3B8', flex: 1 }}>
              <strong style={{ color: '#64748B' }}>Source:</strong> {permit.source}
            </div>
            {permit.source_url && (
              <a
                href={permit.source_url}
                target="_blank"
                rel="noopener noreferrer"
                style={{ fontSize: 11, color: '#2563EB', textDecoration: 'none', whiteSpace: 'nowrap', flexShrink: 0 }}
              >
                Official link ↗
              </a>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
