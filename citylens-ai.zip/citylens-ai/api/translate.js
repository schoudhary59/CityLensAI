export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { roadmap } = req.body;
  if (!roadmap || !roadmap.permits) {
    return res.status(400).json({ error: 'Invalid roadmap data' });
  }

  const translationPrompt = `You are a Spanish translator for a civic permit guide in Montgomery, Alabama.
Translate the specified fields to clear, conversational Spanish for native Spanish-speaking entrepreneurs.
Use practical, accessible Spanish — not bureaucratic or legal Spanish.

TRANSLATE these fields:
- permits[].why
- permits[].fee_note
- first_action
- rejection_risks[].warning
- rejection_risks[].detail
- disclaimer

DO NOT TRANSLATE (keep exactly as English):
- business_type, business_type_id
- permits[].name
- permits[].department
- permits[].address
- permits[].phone
- permits[].hours
- permits[].source
- permits[].source_url
- permits[].fee_range
- total_cost_range, timeline_weeks, classification_confidence

Return the COMPLETE JSON with translated values substituted. No preamble. No markdown fences. Valid JSON only.

ROADMAP TO TRANSLATE:
${JSON.stringify(roadmap)}`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 3000,
        temperature: 0,
        messages: [{ role: 'user', content: translationPrompt }]
      }),
      signal: AbortSignal.timeout(20000)
    });

    const data = await response.json();
    const translated = JSON.parse(data.content[0].text);

    translated.disclaimer = "Esta es una guía basada en información pública de Montgomery y Alabama — no es asesoramiento legal. Confirme siempre los requisitos con la oficina correspondiente antes de presentar cualquier solicitud.";

    return res.status(200).json(translated);
  } catch (err) {
    console.error('Translation error:', err.message);
    return res.status(500).json({ error: 'Translation failed', retry: true });
  }
}
