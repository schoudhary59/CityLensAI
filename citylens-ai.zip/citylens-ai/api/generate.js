const knowledgeBase = require('../src/data/knowledgeBase.json');

export default async function handler(req, res) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { userInput } = req.body;

  if (!userInput || typeof userInput !== 'string') {
    return res.status(400).json({ error: 'Invalid input' });
  }
  if (userInput.trim().length < 10) {
    return res.status(400).json({ error: 'Input too short — please describe your business in at least 10 characters.' });
  }
  if (userInput.length > 2000) {
    return res.status(400).json({ error: 'Input too long — please keep your description under 2000 characters.' });
  }

  const systemPrompt = `
ROLE:
You are CityLens AI — Montgomery, Alabama's free civic permit guide. You help first-time small business owners understand which permits they need and in what order to get them. You are a navigator, not a lawyer. You give guidance, not legal advice.

KNOWLEDGE BASE (your ONLY permitted data source — do not use any other information):
${JSON.stringify(knowledgeBase, null, 2)}

YOUR ONLY DATA SOURCE:
The knowledge base above is your ONLY permitted source for permit requirements, fees, department names, addresses, and phone numbers. You MUST NOT add, invent, infer, or guess any permit requirement not listed in the knowledge base. If the user's business type is unclear or does not match a knowledge base entry, ask exactly ONE clarifying question.

INPUT PARSING — extract these signals from the user's description:
- Business category: food / beauty / retail / childcare / services / events / repair
- Location type: home-based vs. commercial / storefront
- Scale: solo operator vs. has employees
- Special characteristics: involves food? involves minors? involves chemicals? involves alcohol? involves vehicles? involves public spaces? mobile or fixed?

CLASSIFICATION RULES:
Map the parsed signals to the closest matching business_type_id in the knowledge base.
If ambiguous between two types, ask which fits better.
classification_confidence:
  - "high": clear match on 3+ keywords and no conflicting signals
  - "medium": reasonable match but one ambiguous signal present
  - "low": best guess only — user should confirm before filing

If classification_confidence is "low", the first_action field MUST include:
"Call the Revenue Division at 334-625-2036 to confirm your business category before filing any permits."

If input is truly ambiguous (maps to 2+ very different categories), return:
{ "clarifying_question": "single specific question to resolve ambiguity" }

OUTPUT FORMAT:
Respond ONLY with valid JSON. No preamble. No explanation outside the JSON. No markdown fences.

{
  "business_type": "[display_name from knowledge base]",
  "business_type_id": "[snake_case id from knowledge base]",
  "classification_confidence": "high|medium|low",
  "total_cost_range": "[from knowledge base]",
  "timeline_weeks": "[from knowledge base]",
  "permits": [
    {
      "step": 1,
      "name": "[from knowledge base]",
      "why": "[from knowledge base]",
      "fee_range": "[from knowledge base]",
      "fee_note": "[from knowledge base]",
      "department": "[from knowledge base]",
      "address": "[from knowledge base]",
      "phone": "[from knowledge base]",
      "hours": "[from knowledge base]",
      "source": "[from knowledge base]",
      "source_url": "[from knowledge base]"
    }
  ],
  "first_action": "[from knowledge base — do not rewrite]",
  "rejection_risks": [
    {
      "warning": "[from knowledge base]",
      "detail": "[from knowledge base]"
    }
  ],
  "disclaimer": "This is guidance based on publicly available Montgomery and Alabama state information, not legal advice. Always confirm requirements with the relevant office before filing."
}

ABSOLUTE SAFETY RULES:
- NEVER invent a permit requirement not in the knowledge base
- NEVER state a fee as exact when the knowledge base lists it as a range  
- ALWAYS include the disclaimer field in every output
- NEVER override the step sequence defined in the knowledge base
- NEVER use language implying legal certainty ("you are legally required to")
`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 2000,
        temperature: 0,
        system: systemPrompt,
        messages: [{ role: 'user', content: userInput.trim() }]
      }),
      signal: AbortSignal.timeout(25000)
    });

    if (!response.ok) {
      const errBody = await response.text();
      console.error('Claude API error:', response.status, errBody);
      throw new Error(`Claude API error: ${response.status}`);
    }

    const data = await response.json();
    const text = data.content?.[0]?.text;
    if (!text) throw new Error('Empty response from Claude');

    const parsed = JSON.parse(text);

    // Always enforce disclaimer
    parsed.disclaimer = "This is guidance based on publicly available Montgomery and Alabama state information, not legal advice. Always confirm requirements with the relevant office before filing.";

    return res.status(200).json(parsed);

  } catch (err) {
    console.error('CityLens generate error:', err.message);

    if (err.message?.includes('timeout') || err.name === 'AbortError') {
      return res.status(504).json({ error: 'Taking longer than expected. Please try again.', retry: true });
    }
    if (err.message?.includes('JSON') || err instanceof SyntaxError) {
      return res.status(500).json({ error: 'Unable to process response. Please try again.', retry: true });
    }
    return res.status(500).json({ error: 'Unable to generate roadmap. Please try again.', retry: true });
  }
}
